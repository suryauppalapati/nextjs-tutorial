interface InspectionProps {
  approved: number;
  rejected: number;
  unknown: number;
}

type CarouselCTAProps = {
  primaryCTAName: string;
  primaryCTAHandler: () => void;
  secondaryCTAName: string;
  secondaryCTAHandler: () => void;
};

export type { InspectionProps, CarouselCTAProps };
