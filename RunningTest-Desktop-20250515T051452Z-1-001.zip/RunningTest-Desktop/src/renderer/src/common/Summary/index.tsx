import React from "react";

const Summary: React.FC = () => {
  return <div>Summary</div>;
};

export default Summary;
