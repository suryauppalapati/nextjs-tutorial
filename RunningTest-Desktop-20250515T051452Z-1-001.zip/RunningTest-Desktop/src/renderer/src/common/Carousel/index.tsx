import React from 'react'
import { Button } from '@mantine/core'
import { Carousel } from '@mantine/carousel'
import watch1 from '../../assets/watch1.webp'
import watch2 from '../../assets/watch2.webp'
import watch3 from '../../assets/watch3.webp'
import watch4 from '../../assets/watch4.webp'
import watch5 from '../../assets/watch5.webp'
import styles from './Carousel.module.scss'
import { CarouselCTAProps } from '../../types/dials.type'
import { IoMdCheckmark } from 'react-icons/io'
import { RxCross2 } from 'react-icons/rx'

const CardCarousel: React.FC<CarouselCTAProps> = ({ primaryCTAHandler, secondaryCTAHandler }) => {
  const images = [watch1, watch2, watch3, watch4, watch5, watch2]

  return (
    <div className={styles.root}>
      <Carousel
        withIndicators
        height={200}
        slideSize="33.333333%"
        slideGap="md"
        loop
        align="center"
        slidesToScroll={3}
      >
        {images.map((src, index) => (
          <Carousel.Slide key={index}>
            <img src={src} alt={`resource-media-${index + 1}`} />
          </Carousel.Slide>
        ))}
      </Carousel>
      <div className={styles.CTAGroup}>
        <Button className={styles.btnSecondary} onClick={secondaryCTAHandler}>
          <RxCross2 size={16} />
        </Button>
        <Button className={styles.btnPrimary} onClick={primaryCTAHandler}>
          <IoMdCheckmark size={16} />
        </Button>
      </div>
    </div>
  )
}

export default React.memo(CardCarousel)
