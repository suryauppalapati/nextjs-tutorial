import { useState, useEffect } from "react";
import { FiClock } from "react-icons/fi";
import styles from "./Clock.module.scss";

const Clock = () => {
  const [time, setTime] = useState<Date>(new Date());

  // useEffect to update time every second
  useEffect(() => {
    const clock = setInterval(() => {
      setTime(new Date());
    }, 1000);

    // Cleanup the interval on component unmount
    return () => {
      clearInterval(clock);
    };
  }, []);

  const currentTime: string = time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  return (
    <div className={styles.root}>
      <FiClock size={16} />
      <p>
        Current Time: <span>{currentTime}</span>
      </p>
    </div>
  );
};

export default Clock;
