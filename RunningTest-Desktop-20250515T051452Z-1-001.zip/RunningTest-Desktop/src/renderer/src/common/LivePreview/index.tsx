const LivePreview = () => {
  return <div>LivePreview</div>;
};

export default LivePreview;
