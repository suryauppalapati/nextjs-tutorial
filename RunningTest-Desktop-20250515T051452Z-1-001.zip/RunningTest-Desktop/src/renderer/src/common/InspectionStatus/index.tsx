import React from "react";
import { AiOutlineWarning } from "react-icons/ai";
import { IoMdCheckmarkCircleOutline, IoMdClose } from "react-icons/io";
import styles from "./inspectionStatus.module.scss";

const InspectionStatus: React.FC = () => {
  const inspectionData = [
    { icon: <IoMdCheckmarkCircleOutline size={16} />, count: 5 },
    { icon: <IoMdClose size={16} />, count: 2 },
    { icon: <AiOutlineWarning size={16} />, count: 3 },
  ];

  return (
    <div className={styles.root}>
      <p>Inspection status:</p>
      <div className={styles.inspectionData}>
        {inspectionData.map((item, index) => (
          <div key={index} className={styles.section}>
            {item.icon} <span>{item.count.toString().padStart(2, "0")}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default InspectionStatus;
