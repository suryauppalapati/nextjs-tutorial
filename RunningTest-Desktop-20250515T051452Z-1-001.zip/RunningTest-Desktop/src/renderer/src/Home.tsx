import { useState } from "react";
import "./Home.scss";
import { Stepper, Button, Group } from "@mantine/core";
import LivePreview from "./common/LivePreview";
import CardCarousel from "./common/Carousel";
import Clock from "./common/Clock";
import InspectionStatus from "./common/InspectionStatus";
import Summary from "./common/Summary";

// Dynamically render the component for the current step
const Home: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number>(0);

  const nextStep = () => setActiveStep((prev) => Math.min(prev + 1, 6));
  const prevStep = () => setActiveStep((prev) => Math.max(prev - 1, 0));

  // Handlers for CardCarousel's CTAs
  const handlePrimaryCTA = () => {
    console.log("Primary CTA clicked");
  };

  const handleSecondaryCTA = () => {
    console.log("Secondary CTA clicked");
  };

  // Map components to steps
  const componentStepMapping: Record<number, JSX.Element | null> = {
    0: <LivePreview />,
    2: null,
    3: (
      <CardCarousel
        primaryCTAName="Approve"
        primaryCTAHandler={handlePrimaryCTA}
        secondaryCTAName="Reject"
        secondaryCTAHandler={handleSecondaryCTA}
      />
    ),
    4: (
      <CardCarousel
        primaryCTAName="Approve"
        primaryCTAHandler={handlePrimaryCTA}
        secondaryCTAName="Reject"
        secondaryCTAHandler={handleSecondaryCTA}
      />
    ),
    5: <Summary />,
  };

  const CurrentStepComponent = componentStepMapping[activeStep] || null;

  return (
    <div className="root">
      <Stepper active={activeStep} onStepClick={setActiveStep} size="xs">
        {["Inspect dials", "Verify dials", "Classify unknown", "Verify rejected", "Pick rejected", "Summary"].map(
          (description, index) => (
            <Stepper.Step key={index} label={`Step ${index + 1}`} description={description} />
          )
        )}
      </Stepper>

      <div className="inspectionInfo">
        <Clock />
        <InspectionStatus />
      </div>

      <div className="stepperComponent">{CurrentStepComponent}</div>

      <Group justify="center" mt="xl">
        <Button className="btnNavigation" variant="default" onClick={prevStep} disabled={activeStep === 0}>
          Back
        </Button>
        <Button className="btnNavigation" onClick={nextStep}>
          Next Step
        </Button>
      </Group>
    </div>
  );
};

export default Home;
